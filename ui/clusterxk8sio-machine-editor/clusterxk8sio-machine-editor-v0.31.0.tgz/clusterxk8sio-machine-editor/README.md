# Machine Editor

[Machine Editor by AppsCode](https://appscode.com) - Machine Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/clusterxk8sio-machine-editor --version=v0.31.0
$ helm upgrade -i clusterxk8sio-machine-editor appscode/clusterxk8sio-machine-editor -n default --create-namespace --version=v0.31.0
```

## Introduction

This chart deploys a Machine Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `clusterxk8sio-machine-editor`:

```bash
$ helm upgrade -i clusterxk8sio-machine-editor appscode/clusterxk8sio-machine-editor -n default --create-namespace --version=v0.31.0
```

The command deploys a Machine Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `clusterxk8sio-machine-editor`:

```bash
$ helm uninstall clusterxk8sio-machine-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `clusterxk8sio-machine-editor` chart and their default values.

|     Parameter      | Description |                Default                |
|--------------------|-------------|---------------------------------------|
| apiVersion         |             | <code>cluster.x-k8s.io/v1beta1</code> |
| kind               |             | <code>Machine</code>                  |
| metadata.name      |             | <code>machine</code>                  |
| metadata.namespace |             | <code>default</code>                  |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i clusterxk8sio-machine-editor appscode/clusterxk8sio-machine-editor -n default --create-namespace --version=v0.31.0 --set apiVersion=cluster.x-k8s.io/v1beta1
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i clusterxk8sio-machine-editor appscode/clusterxk8sio-machine-editor -n default --create-namespace --version=v0.31.0 --values values.yaml
```
